在eclipse里面run dialog->target里面可以设置.如果是命令行可以使用参数emulator -skin HVGA-L，也可使用F12，或是ctrl+F11。
我一般习惯用小键盘的7和9来转屏。
这里转一份我翻译的模拟器的快捷键，原来是英文的：
```  
模拟器对应键	按键
Home	HOME
Menu (left softkey)	F2/Page-up
Star (right softkey)	Shift-F2/Page Down (好像没效)
Back	ESC
Call/Dial	F3
Hangup/End call	F4
Search	F5
Power	F7(没试成功)
volume up	KEYPAD_PLUS, Ctrl-5
volume down	KEYPAD_MINUS, Ctrl-F6
Camera	Ctrl-KEYPAD_5, Ctrl-F3(没试成功)
旋转到之前的屏幕方向	KEYPAD_7, Ctrl-F11
旋转到之后的屏幕方向	KEYPAD_9, Ctrl-F12
切换网络通断	F8
Toggle code profiling(不懂)	F9 (用参数 -trace启动才有效，没试)
全屏模式	Alt-Enter
轨迹球	F6
轨迹球（要一直按着）	Delete
left、up、right、down	KEYPAD_4/8/6/2
center/select	KEYPAD_5
Onion alpha
increase/decrease(不懂)	KEYPAD_MULTIPLY(*)
KEYPAD_DIVIDE(/)
```